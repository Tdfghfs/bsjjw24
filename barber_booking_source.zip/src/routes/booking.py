from flask import Blueprint, request, jsonify
from src.models.booking import Booking, db
from datetime import datetime

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/bookings', methods=['GET'])
def get_bookings():
    """الحصول على قائمة الحجوزات"""
    bookings = Booking.query.order_by(Booking.booking_time).all()
    return jsonify([booking.to_dict() for booking in bookings])

@booking_bp.route('/bookings', methods=['POST'])
def create_booking():
    """إنشاء حجز جديد"""
    data = request.json
    
    if not data or 'client_name' not in data or 'booking_time' not in data:
        return jsonify({'error': 'يجب توفير اسم العميل ووقت الحجز'}), 400
    
    try:
        booking_time = datetime.strptime(data['booking_time'], '%Y-%m-%d %H:%M')
        
        # التحقق من عدم وجود حجز في نفس الوقت
        existing_booking = Booking.query.filter_by(booking_time=booking_time).first()
        if existing_booking:
            return jsonify({'error': 'هذا الوقت محجوز بالفعل'}), 400
        
        new_booking = Booking(
            client_name=data['client_name'],
            booking_time=booking_time,
            estimated_duration=data.get('estimated_duration', 30)
        )
        
        db.session.add(new_booking)
        db.session.commit()
        
        return jsonify(new_booking.to_dict()), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@booking_bp.route('/bookings/<int:booking_id>', methods=['DELETE'])
def delete_booking(booking_id):
    """إلغاء حجز"""
    booking = Booking.query.get_or_404(booking_id)
    
    db.session.delete(booking)
    db.session.commit()
    
    return jsonify({'message': 'تم إلغاء الحجز بنجاح'}), 200

@booking_bp.route('/bookings/queue', methods=['GET'])
def get_queue():
    """الحصول على قائمة الانتظار الحالية"""
    current_time = datetime.utcnow()
    
    # الحصول على الحجوزات المستقبلية مرتبة حسب الوقت
    upcoming_bookings = Booking.query.filter(
        Booking.booking_time >= current_time
    ).order_by(Booking.booking_time).all()
    
    # الحصول على الحجز الحالي (إن وجد)
    current_booking = Booking.query.filter(
        Booking.booking_time <= current_time,
        Booking.booking_time >= current_time.replace(hour=current_time.hour-1)
    ).order_by(Booking.booking_time.desc()).first()
    
    queue = []
    
    # إضافة الحجز الحالي إلى القائمة مع الوقت المتبقي
    if current_booking:
        booking_data = current_booking.to_dict()
        booking_data['remaining_time'] = current_booking.get_remaining_time(current_time)
        booking_data['status'] = 'active'
        queue.append(booking_data)
    
    # إضافة الحجوزات القادمة إلى القائمة
    for booking in upcoming_bookings:
        booking_data = booking.to_dict()
        booking_data['remaining_time'] = booking.get_remaining_time(current_time)
        queue.append(booking_data)
    
    return jsonify(queue)
