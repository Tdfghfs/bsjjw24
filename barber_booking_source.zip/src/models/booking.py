from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_name = db.Column(db.String(100), nullable=False)
    booking_time = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    estimated_duration = db.Column(db.Integer, default=30)  # مدة الحلاقة بالدقائق
    status = db.Column(db.String(20), default='pending')  # pending, active, completed, cancelled
    
    def __repr__(self):
        return f'<Booking {self.client_name} at {self.booking_time}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'client_name': self.client_name,
            'booking_time': self.booking_time.strftime('%Y-%m-%d %H:%M'),
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M'),
            'estimated_duration': self.estimated_duration,
            'status': self.status
        }
    
    def get_remaining_time(self, current_time=None):
        """حساب الوقت المتبقي للموعد بالدقائق"""
        if not current_time:
            current_time = datetime.utcnow()
        
        if current_time > self.booking_time:
            # إذا كان الوقت الحالي بعد موعد الحجز
            time_diff = (current_time - self.booking_time).total_seconds() / 60
            if time_diff > self.estimated_duration:
                return 0  # انتهى الموعد
            else:
                return max(0, self.estimated_duration - time_diff)  # الوقت المتبقي
        else:
            # إذا كان الموعد لم يبدأ بعد
            return self.estimated_duration
